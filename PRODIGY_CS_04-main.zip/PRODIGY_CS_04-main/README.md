This is one of my internship task at Prodigy InfoTech.
This code is a basic keylogger program written in python using pynput library which asks user for a specified time till the keystrokes are captured. Then the log is saved to a `keylogger_log.txt` file which can be viewed later.
`pynput` library must be installed prior to running this code.
**Running this code might require superuser/administrator privileges. I tested this code on my Kali Linux terminal in my virtual machine where I had to be a superuser.**
